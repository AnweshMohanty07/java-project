import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

class DatabaseConnection {
    // Database URL, username, and password
    private static final String URL = "jdbc:mysql://localhost:3306/library_system";
    private static final String USER = "root"; // Replace with your MySQL username
    private static final String PASSWORD = "Papun@90788"; // Replace with your MySQL password

    // Method to establish and return a database connection
    public static Connection getConnection() throws SQLException {
        Connection connection = null;
        try {
            // Load the MySQL JDBC Driver (optional, but good practice)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found. Add it to your project's library.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Connection failed! Check the database URL, username, or password.");
            throw e;
        }
        return connection;
    }

    // For testing the connection
    public static void main(String[] args) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                System.out.println("Connected to the database successfully!");
            } else {
                System.out.println("Failed to connect to the database.");
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
