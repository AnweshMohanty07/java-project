import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

class Student {
    private final String name;
    private final String regNumber;
    private final String email;

    public Student(String name, String regNumber, String email) {
        this.name = name;
        this.regNumber = regNumber;
        this.email = email;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Reg No: " + regNumber + ", Email: " + email;
    }
}

class LibraryGUI {
    private static ArrayList<Student> studentList = new ArrayList<>();

    public static void main(String[] args) {
        // Main Menu Frame
        JFrame mainFrame = new JFrame("Library Management System");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(500, 350);
        mainFrame.setLayout(new GridLayout(4, 1, 10, 10));
        mainFrame.setLocationRelativeTo(null);  // Center the window

        // Set background color for the main frame
        mainFrame.getContentPane().setBackground(new Color(255, 248, 220));  // Light beige background

        JButton registerStudentButton = new JButton("Register Student");
        JButton showAllStudentsButton = new JButton("Show All Registered Students");
        JButton exitButton = new JButton("Exit");

        // Customize buttons with colors
        registerStudentButton.setBackground(new Color(34, 139, 34));  // Green
        registerStudentButton.setForeground(Color.WHITE);
        registerStudentButton.setFont(new Font("Arial", Font.BOLD, 14));

        showAllStudentsButton.setBackground(new Color(70, 130, 180));  // Steel blue
        showAllStudentsButton.setForeground(Color.WHITE);
        showAllStudentsButton.setFont(new Font("Arial", Font.BOLD, 14));

        exitButton.setBackground(new Color(255, 69, 0));  // Red-Orange
        exitButton.setForeground(Color.WHITE);
        exitButton.setFont(new Font("Arial", Font.BOLD, 14));

        mainFrame.add(registerStudentButton);
        mainFrame.add(showAllStudentsButton);
        mainFrame.add(exitButton);

        // Register Student Button Action
        registerStudentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openStudentRegistrationForm();
            }
        });

        // Show All Students Button Action
        showAllStudentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (studentList.isEmpty()) {
                    JOptionPane.showMessageDialog(mainFrame, "No students registered yet.", "Info", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    StringBuilder students = new StringBuilder("Registered Students:\n");
                    for (Student student : studentList) {
                        students.append(student).append("\n");
                    }
                    JOptionPane.showMessageDialog(mainFrame, students.toString(), "Registered Students", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Exit Button Action
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        mainFrame.setVisible(true);
    }

    private static void openStudentRegistrationForm() {
        JFrame frame = new JFrame("Student Registration");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);  // Center the window

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(255, 248, 220));  // Light beige background for form

        // Customizing labels and text fields
        JLabel nameLabel = new JLabel("Student Name:");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        nameLabel.setForeground(new Color(0, 0, 128));  // Dark Blue
        JTextField nameField = new JTextField();
        nameField.setBackground(Color.WHITE);
        nameField.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel regNumLabel = new JLabel("Registration Number:");
        regNumLabel.setFont(new Font("Arial", Font.BOLD, 14));
        regNumLabel.setForeground(new Color(0, 0, 128));
        JTextField regNumField = new JTextField();
        regNumField.setBackground(Color.WHITE);
        regNumField.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 14));
        emailLabel.setForeground(new Color(0, 0, 128));
        JTextField emailField = new JTextField();
        emailField.setBackground(Color.WHITE);
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));

        JButton registerButton = new JButton("Register");
        registerButton.setBackground(new Color(34, 139, 34));  // Green
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        registerButton.setFocusPainted(false);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(255, 69, 0));  // Red-Orange
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Arial", Font.BOLD, 14));
        cancelButton.setFocusPainted(false);

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(regNumLabel);
        panel.add(regNumField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(registerButton);
        panel.add(cancelButton);

        // Register Button Action
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String regNum = regNumField.getText();
                String email = emailField.getText();

                if (name.isEmpty() || regNum.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    studentList.add(new Student(name, regNum, email));
                    JOptionPane.showMessageDialog(frame, "Student Registered Successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    frame.dispose();
                }
            }
        });

        // Cancel Button Action
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.add(panel);
        frame.setVisible(true);
    }
}
