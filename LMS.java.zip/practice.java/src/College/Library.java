package College;

import java.util.Scanner;

public class Library {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Books books = new Books();
        Students students = new Students();

        int choice;
        do {
            books.dispMenu();
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    Book b = new Book();
                    books.addBook(b);
                    break;
                case 2:
                    books.upgradeBookQty();
                    break;
                case 3:
                    System.out.println("1. Search By S.No\n2. Search By Author Name");
                    int searchChoice = input.nextInt();
                    switch (searchChoice) {
                        case 1:
                            books.searchBySno();
                            break;
                        case 2:
                            books.searchByAuthorName();
                            break;
                    }
                    break;
                case 4:
                    books.showAllBooks();
                    break;
                case 5:
                    Student s = new Student();
                    students.addStudent(s);
                    break;
                case 6:
                    students.showAllStudents();
                    break;
                case 7:
                    students.checkOutBook(books);
                    break;
                case 8:
                    students.checkInBook(books);
                    break;
                case 0:
                    System.out.println("Exiting Application...");
                    break;
                default:
                    System.out.println("Invalid Choice.");
            }
        } while (choice != 0);

        input.close();
    }
}