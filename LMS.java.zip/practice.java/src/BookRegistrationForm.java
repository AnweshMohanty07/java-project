import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class BookRegistrationForm {
    public static void main(String[] args) {
        // Create the frame
        JFrame frame = new JFrame("Book Registration");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(450, 350);
        frame.setLocationRelativeTo(null);  // Center the frame

        // Set background color for the frame
        frame.getContentPane().setBackground(new Color(255, 250, 240));  // Light beige background

        // Create a panel with GridLayout
        JPanel panel = new JPanel(new GridLayout(6, 2, 15, 15));  // Adjusted grid for spacing
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(255, 250, 240));  // Light beige background

        // Label and Text Field for Serial Number
        JLabel serialLabel = new JLabel("Serial Number:");
        serialLabel.setFont(new Font("Arial", Font.BOLD, 14));
        serialLabel.setForeground(new Color(0, 0, 128));  // Dark Blue
        JTextField serialField = new JTextField();
        serialField.setFont(new Font("Arial", Font.PLAIN, 14));
        serialField.setBackground(Color.WHITE);

        // Label and Text Field for Book Name
        JLabel nameLabel = new JLabel("Book Name:");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        nameLabel.setForeground(new Color(0, 0, 128));  // Dark Blue
        JTextField nameField = new JTextField();
        nameField.setFont(new Font("Arial", Font.PLAIN, 14));
        nameField.setBackground(Color.WHITE);

        // Label and Text Field for Author Name
        JLabel authorLabel = new JLabel("Author Name:");
        authorLabel.setFont(new Font("Arial", Font.BOLD, 14));
        authorLabel.setForeground(new Color(0, 0, 128));  // Dark Blue
        JTextField authorField = new JTextField();
        authorField.setFont(new Font("Arial", Font.PLAIN, 14));
        authorField.setBackground(Color.WHITE);

        // Label and Text Field for Quantity
        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setFont(new Font("Arial", Font.BOLD, 14));
        quantityLabel.setForeground(new Color(0, 0, 128));  // Dark Blue
        JTextField quantityField = new JTextField();
        quantityField.setFont(new Font("Arial", Font.PLAIN, 14));
        quantityField.setBackground(Color.WHITE);

        // Add components to the panel
        panel.add(serialLabel);
        panel.add(serialField);
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(authorLabel);
        panel.add(authorField);
        panel.add(quantityLabel);
        panel.add(quantityField);

        // Register Button
        JButton registerButton = new JButton("Register Book");
        registerButton.setBackground(new Color(34, 139, 34));  // Green
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        registerButton.setFocusPainted(false);  // Removes the button border when clicked

        // Cancel Button
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(255, 69, 0));  // Red-Orange
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Arial", Font.BOLD, 14));
        cancelButton.setFocusPainted(false);

        // Add buttons to the panel
        panel.add(registerButton);
        panel.add(cancelButton);

        // Add action listeners for buttons
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String serial = serialField.getText();
                String name = nameField.getText();
                String author = authorField.getText();
                String quantity = quantityField.getText();

                if (serial.isEmpty() || name.isEmpty() || author.isEmpty() || quantity.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Book Registered Successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    // Code to register the book into your system
                }
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();  // Close the form
            }
        });

        // Add panel to frame and make it visible
        frame.add(panel);
        frame.setVisible(true);
    }
}
