import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

// Book class to hold book information
class Book {
    private String name;
    private String author;
    private String serialNumber;  // Added serial number field

    // Constructor
    public Book(String name, String author, String serialNumber) {
        this.name = name;
        this.author = author;
        this.serialNumber = serialNumber;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    // To display book info including serial number
    @Override
    public String toString() {
        return "Book Name: " + name + ", Author: " + author + ", Serial Number: " + serialNumber;
    }
}

// GUI class for Student Book Registration and Checking
class StudentBookMappingGUI {
    private static final HashMap<String, String> studentMapping = new HashMap<>();  // Map for student registration info
    private static final HashMap<String, Book> studentBookMapping = new HashMap<>(); // Map for student-book associations

    public static void main(String[] args) {
        // Create the main frame
        JFrame frame = new JFrame("Student Book Registration System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);  // Center the window

        // Create a panel with GridLayout
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(240, 248, 255));  // Light blue background

        // Student Registration Fields with Labels and Text Fields
        JLabel regNumLabel = new JLabel("Enter Student Registration Number:");
        regNumLabel.setForeground(new Color(0, 0, 128));  // Dark blue color for labels
        regNumLabel.setFont(new Font("Arial", Font.BOLD, 14));
        JTextField regNumField = new JTextField();
        regNumField.setBackground(Color.WHITE);
        regNumField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(regNumLabel);
        panel.add(regNumField);

        JLabel studentNameLabel = new JLabel("Enter Student Name:");
        studentNameLabel.setForeground(new Color(0, 0, 128));
        studentNameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        JTextField studentNameField = new JTextField();
        studentNameField.setBackground(Color.WHITE);
        studentNameField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(studentNameLabel);
        panel.add(studentNameField);

        JLabel bookNameLabel = new JLabel("Enter Book Name:");
        bookNameLabel.setForeground(new Color(0, 0, 128));
        bookNameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        JTextField bookNameField = new JTextField();
        bookNameField.setBackground(Color.WHITE);
        bookNameField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(bookNameLabel);
        panel.add(bookNameField);

        JLabel bookSerialNumberLabel = new JLabel("Enter Book Serial Number:");  // Changed label
        bookSerialNumberLabel.setForeground(new Color(0, 0, 128));  // Dark blue color for labels
        bookSerialNumberLabel.setFont(new Font("Arial", Font.BOLD, 14));
        JTextField bookSerialNumberField = new JTextField();  // Changed field
        bookSerialNumberField.setBackground(Color.WHITE);
        bookSerialNumberField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(bookSerialNumberLabel);
        panel.add(bookSerialNumberField);

        // Buttons for registering and checking
        JButton registerButton = new JButton("Register Borrowing Books by Student");  // Changed button text
        registerButton.setBackground(new Color(34, 139, 34));  // Green color for register button
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        registerButton.setFocusPainted(false);
        registerButton.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        JButton checkButton = new JButton("Check Borrowed Books by Student");  // Updated button text
        checkButton.setBackground(new Color(70, 130, 180));  // Steel blue color for check button
        checkButton.setForeground(Color.WHITE);
        checkButton.setFont(new Font("Arial", Font.BOLD, 14));
        checkButton.setFocusPainted(false);
        checkButton.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        panel.add(registerButton);
        panel.add(checkButton);

        // Action Listener for Register Button
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String regNum = regNumField.getText();
                String studentName = studentNameField.getText();
                String bookName = bookNameField.getText();
                String bookSerialNumber = bookSerialNumberField.getText();

                if (regNum.isEmpty() || studentName.isEmpty() || bookName.isEmpty() || bookSerialNumber.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    studentMapping.put(regNum, studentName); // Register the student
                    studentBookMapping.put(regNum, new Book(bookName, "Unknown", bookSerialNumber)); // Associate student with book (author as "Unknown")
                    JOptionPane.showMessageDialog(frame, "Student Registered and Book Borrowed Successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Action Listener for Check Button
        checkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String regNum = regNumField.getText();

                if (regNum.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter a registration number!", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (studentBookMapping.containsKey(regNum)) {
                    Book book = studentBookMapping.get(regNum);
                    String studentName = studentMapping.get(regNum);
                    JOptionPane.showMessageDialog(frame, "Student with Reg No: " + regNum + " (" + studentName + ") has borrowed the book: " + book, "Book Found", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "No book record found for Reg No: " + regNum, "Not Found", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        // Add panel to frame and make it visible
        frame.add(panel);
        frame.setVisible(true);
    }
}
